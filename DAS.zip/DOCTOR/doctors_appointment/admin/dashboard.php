<?php include'db_connect.php' ?>

<div class="row">
    <div class="col-md-4">
        <div class="card">
            <div class="card text-white bg-info">
                <div class="card-body text-white">
                    <h4><span class="float-right summary_icon"><i class="fa fa-users"></i></span>
					<b><?php echo $conn->query("SELECT * FROM users")->num_rows; ?></b></h4>
			        <b>Users</b>   
                </div>
				
				<div class="list-group-item-info list-group-item list-group-item-action">
					<div class="row">
						<div class="col-sm-8">
							<p class="">view info</p>
						</div>
						<div class="col-sm-4">
							<a href="index.php?page=users"><i class="fa fa-arrow-right float-sm-right"></i></a>
						</div>
                    </div>
                </div>
            </div>
		</div>
	</div>
	
	<div class="col-md-4">
        <div class="card">
            <div class="card text-white bg-success">
                <div class="card-body text-white">
                    <h4><span class="float-right summary_icon"><i class="fa fa-user-md"></i></span>
                    <b>
					<?php echo $conn->query("SELECT * FROM users where type=2")->num_rows; ?></b></h4>
			        <b>Doctors</b>   
                </div>
				
				<div class="list-group-item-success list-group-item list-group-item-action">
					<div class="row">
						<div class="col-sm-8">
							<p class="">view info</p>
						</div>
						<div class="col-sm-4">
							<a href="index.php?page=doctors"><i class="fa fa-arrow-right float-sm-right"></i></a>
						</div>
                    </div>
                </div>
            </div>
		</div>
	</div>
	
	<div class="col-md-4">
        <div class="card">
            <div class="card text-white bg-secondary">
                <div class="card-body text-white">
                    <h4><span class="float-right summary_icon"><i class="fa fa-calendar"></i></span>
                    <b>
					<?php echo $conn->query("SELECT * FROM appointment_list")->num_rows; ?></b></h4>
			        <b>Appointments</b>   
                </div>
				
				<div class="list-group-item-secondary list-group-item list-group-item-action">
					<div class="row">
						<div class="col-sm-8">
							<p class="">view info</p>
						</div>
						<div class="col-sm-4">
							<a href="index.php?page=appointments"><i class="fa fa-arrow-right float-sm-right"></i></a>
						</div>
                    </div>
                </div>
            </div>
		</div>
	</div>
	
	<div class="col-md-4">
        <div class="card">
            <div class="card text-white bg-warning">
                <div class="card-body text-white">
                    <h4><span class="float-right summary_icon"><i class="fa fa-comments"></i></span>
                    <b>
					<?php echo $conn->query("SELECT * FROM feedback")->num_rows; ?></b></h4>  
			        <b>Feedback</b> 
                </div>
				
				<div class="list-group-item-warning list-group-item list-group-item-action">
					<div class="row">
						<div class="col-sm-8">
							<p class="">view info</p>
						</div>
						<div class="col-sm-4">
							<a href="index.php?page=view_feedback"><i class="fa fa-arrow-right float-sm-right"></i></a>
						</div>
                    </div>
                </div>
            </div>
		</div>
	</div>
</div>
				
                        