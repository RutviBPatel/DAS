-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 24, 2022 at 02:49 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `doctors_appointment_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment_list`
--

CREATE TABLE `appointment_list` (
  `id` int(10) NOT NULL,
  `doctor_id` int(10) NOT NULL,
  `patient_id` int(10) NOT NULL,
  `schedule` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0= for verification, 1=confirmed,2= reschedule,3=done',
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `appointment_list`
--

INSERT INTO `appointment_list` (`id`, `doctor_id`, `patient_id`, `schedule`, `status`, `date_created`) VALUES
(10, 3, 12, '2021-03-09 11:30:00', 1, '2021-03-11 15:34:47'),
(15, 8, 15, '2022-12-10 11:00:00', 3, '2022-12-09 21:42:00'),
(17, 9, 15, '2022-12-12 17:00:00', 1, '2022-12-12 20:17:15'),
(18, 8, 107, '2022-12-15 12:00:00', 0, '2022-12-13 09:37:20');

-- --------------------------------------------------------

--
-- Table structure for table `doctors_list`
--

CREATE TABLE `doctors_list` (
  `id` int(10) NOT NULL,
  `name` text NOT NULL,
  `name_pref` varchar(5) NOT NULL,
  `clinic_address` varchar(60) NOT NULL,
  `contact` varchar(14) NOT NULL,
  `email` varchar(30) NOT NULL,
  `specialty_ids` text NOT NULL,
  `img_path` varchar(90) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doctors_list`
--

INSERT INTO `doctors_list` (`id`, `name`, `name_pref`, `clinic_address`, `contact`, `email`, `specialty_ids`, `img_path`, `date_created`) VALUES
(1, 'DR. M K DAVE', 'M.D.', 'Nilam nagar, Ahemdabad', '+91 8574965689', 'mkdave@gmail.com', '[3]', 'mkdave.png', '2022-12-02 09:00:09'),
(3, 'DR. YASH PATEL', 'BDS.', 'Vardhman society, Vadodara', '+91 9316156136', 'yashpatel@gmail.com', '[2]', 'yash.jpg', '2022-12-06 10:48:18'),
(4, 'DR. SEJAL PATEL', '', 'Sardarnagar gurukul, Bhavnagar', '+91 8200065192', 'sejalpatel@gmail.com', '[5]', 'sejalpatel.png', '2022-12-03 11:26:44'),
(8, 'NANDINI CHOPDA', 'DR.', 'Silver stone,Rajkot ', '+91 9696858574', 'nandinichopda@gmail.com', '[1]', '1670601540_nandini.jpg', '2022-12-09 21:29:16'),
(9, 'MITESH DAVRA', 'DR.', 'Near sumul dairy, Surat', '+91 9874563210', 'miteshdavra@gmail.com', '[6]', '1670856180_miteshdavra.png', '2022-12-12 20:13:11'),
(10, 'PARAS PATEL', 'M.D.', 'Near kakriya lake, Ahemadabad', '+91 9898565623', 'paraspatel@gmail.com', '[8]', '1670857980_paraspatel.png', '2022-12-12 20:43:37'),
(11, 'PARITA PATEL', 'DR.', 'Near kakriya lake, Ahemadabad', '+91 7698589244', 'paritapatel@gmail.com', '[8]', '1670858280_paritamaniya.png', '2022-12-12 20:48:49'),
(12, 'AVANI TRIVEDI', 'MBBS.', 'Jewels circle, Bhavnagar', '+91 9712170100', 'avanitrivedi@gmail.com', '[9]', '1670946360_avani.jpg', '2022-12-13 21:16:58'),
(13, 'DR. B K SHAH', 'BHMS.', 'Yogi chowk, Surat', '+91 9988656523', 'bkshah@gmail.com', '[4]', '1670947860_bkshah.jpg', '2022-12-13 21:41:04');

-- --------------------------------------------------------

--
-- Table structure for table `doctors_schedule`
--

CREATE TABLE `doctors_schedule` (
  `id` int(10) NOT NULL,
  `doctor_id` int(10) NOT NULL,
  `day` varchar(20) NOT NULL,
  `time_from` time NOT NULL,
  `time_to` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doctors_schedule`
--

INSERT INTO `doctors_schedule` (`id`, `doctor_id`, `day`, `time_from`, `time_to`) VALUES
(3, 2, 'Monday', '10:00:00', '17:00:00'),
(4, 2, 'Wednesday', '10:00:00', '17:00:00'),
(5, 3, 'Monday', '10:00:00', '15:00:00'),
(6, 3, 'Tuesday', '10:00:00', '15:00:00'),
(7, 3, 'Wednesday', '10:00:00', '15:00:00'),
(8, 3, 'Thursday', '10:00:00', '15:00:00'),
(9, 3, 'Friday', '10:00:00', '15:00:00'),
(10, 4, 'Monday', '09:30:00', '18:30:00'),
(11, 4, 'Tuesday', '09:30:00', '18:30:00'),
(12, 4, 'Saterday', '09:30:00', '18:30:00'),
(13, 7, 'Monday', '13:00:00', '18:00:00'),
(14, 7, 'Tuesday', '13:00:00', '18:00:00'),
(15, 7, 'Wednesday', '13:00:00', '18:00:00'),
(16, 8, 'Thursday', '10:00:00', '15:00:00'),
(17, 8, 'Friday', '10:00:00', '15:00:00'),
(18, 8, 'Saturday', '10:00:00', '15:00:00'),
(19, 9, 'Monday', '14:00:00', '18:00:00'),
(20, 9, 'Wednesday', '14:00:00', '18:00:00'),
(21, 9, 'Friday', '14:00:00', '18:00:00'),
(22, 11, 'Tuesday', '10:00:00', '15:00:00'),
(23, 11, 'Thursday', '10:00:00', '15:00:00'),
(24, 11, 'Saturday', '10:00:00', '15:00:00'),
(25, 10, 'Monday', '15:00:00', '18:00:00'),
(26, 10, 'Wednesday', '15:00:00', '18:00:00'),
(27, 10, 'Friday', '15:00:00', '18:00:00'),
(29, 1, 'Monday', '10:10:00', '00:00:00'),
(30, 1, 'Tuesday', '00:00:00', '00:00:00'),
(31, 1, 'Wednesday', '00:00:00', '00:00:00'),
(32, 1, 'Thursday', '00:12:00', '00:00:00'),
(33, 1, 'Friday', '00:00:00', '00:00:00'),
(34, 1, 'Saturday', '00:00:00', '00:00:00'),
(35, 1, 'Sunday', '00:00:00', '00:00:00'),
(36, 4, 'Friday', '00:00:00', '00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(10) NOT NULL,
  `email` varchar(30) NOT NULL,
  `feedback` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `email`, `feedback`) VALUES
(0, 'Pratik Saliya', 'hello');

-- --------------------------------------------------------

--
-- Table structure for table `medical_specialty`
--

CREATE TABLE `medical_specialty` (
  `id` int(10) NOT NULL,
  `name` text NOT NULL,
  `img_path` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `medical_specialty`
--

INSERT INTO `medical_specialty` (`id`, `name`, `img_path`) VALUES
(1, 'Pediatrics', '1670598540_Pediatrics.png'),
(2, 'Dentist', '1671550020_teeth.jpg'),
(3, 'Cardiology', '1670598780_Cardiology.png'),
(4, 'Orthopaedics', '1670518320_Orthopaedics.jpg'),
(5, 'Obstetrician/gynecologists', '1670517360_gynecologists.jpg'),
(6, 'Neurologists', '1670516640_mind.jpg'),
(8, 'Skin Disease', '1670857200_skin disease.png'),
(9, 'Ophthalmology', '1670944680_eye.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `system_settings`
--

CREATE TABLE `system_settings` (
  `id` int(10) NOT NULL,
  `email` varchar(30) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `cover_img` text NOT NULL,
  `about_content` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `system_settings`
--

INSERT INTO `system_settings` (`id`, `email`, `contact`, `cover_img`, `about_content`) VALUES
(1, 'info@sample.com', '+6948 8542 623', '1615454520_ing.jpg', '&lt;p style=&quot;text-align: center; background: transparent; position: relative;&quot;&gt;&lt;span style=&quot;font-size:28px;background: transparent; position: relative;&quot;&gt;ABOUT US&lt;/span&gt;&lt;/b&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center; background: transparent; position: relative;&quot;&gt;&lt;span style=&quot;background: transparent; position: relative; font-size: 14px;&quot;&gt;&lt;span style=&quot;font-size:28px;background: transparent; position: relative;&quot;&gt;&lt;b style=&quot;margin: 0px; padding: 0px; color: rgb(0, 0, 0); font-family: &amp;quot;Open Sans&amp;quot;, Arial, sans-serif; text-align: justify;&quot;&gt;Lorem Ipsum&lt;/b&gt;&lt;span style=&quot;color: rgb(0, 0, 0); font-family: &amp;quot;Open Sans&amp;quot;, Arial, sans-serif; font-weight: 400; text-align: justify;&quot;&gt;&amp;nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&amp;#x2019;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.&lt;/span&gt;&lt;br&gt;&lt;/span&gt;&lt;/b&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center; background: transparent; position: relative;&quot;&gt;&lt;span style=&quot;background: transparent; position: relative; font-size: 14px;&quot;&gt;&lt;span style=&quot;font-size:28px;background: transparent; position: relative;&quot;&gt;&lt;span style=&quot;color: rgb(0, 0, 0); font-family: &amp;quot;Open Sans&amp;quot;, Arial, sans-serif; font-weight: 400; text-align: justify;&quot;&gt;&lt;br&gt;&lt;/span&gt;&lt;/b&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center; background: transparent; position: relative;&quot;&gt;&lt;span style=&quot;background: transparent; position: relative; font-size: 14px;&quot;&gt;&lt;span style=&quot;font-size:28px;background: transparent; position: relative;&quot;&gt;&lt;h2 style=&quot;font-size:28px;background: transparent; position: relative;&quot;&gt;Where does it come from?&lt;/h2&gt;&lt;p style=&quot;text-align: center; margin-bottom: 15px; padding: 0px; color: rgb(0, 0, 0); font-family: &amp;quot;Open Sans&amp;quot;, Arial, sans-serif; font-weight: 400;&quot;&gt;Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of &quot;de Finibus Bonorum et Malorum&quot; (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, &quot;Lorem ipsum dolor sit amet..&quot;, comes from a line in section 1.10.32.&lt;/p&gt;&lt;/span&gt;&lt;/b&gt;&lt;/span&gt;&lt;/p&gt;');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) NOT NULL,
  `doctor_id` int(10) NOT NULL,
  `name` varchar(30) NOT NULL,
  `address` varchar(60) NOT NULL,
  `contact` varchar(14) NOT NULL,
  `username` varchar(60) NOT NULL,
  `password` varchar(10) NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 2 COMMENT '1=admin , 2 = doctor,3=patient'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `doctor_id`, `name`, `address`, `contact`, `username`, `password`, `type`) VALUES
(1, 0, 'Administrator', '', '', 'admin', 'admin123', 1),
(10, 3, 'DR.DR. YASH PATEL, BDS.', 'Vardhman society, Vadodara', '+91 9316156136', 'yashpatel@gmail.com', 'yash123', 2),
(12, 0, 'Dhanani Mayuri', 'three corner street,vallabhipur-364310', '7946138520', 'dhananimayuri@gmail.com', 'mayuri123', 3),
(13, 2, 'DR.M K DAVE, M.D.', 'Nilam nagar, Ahemdabad', '+91 8574965689', 'mkdave@gmail.com', 'mkdave123', 2),
(15, 0, 'Pratik Saliya', 'khandiya hanuman manidir, vallabhipur ,gujarat-364310', '7946138520', 'pratiksaliya@gmail.com', 'pratik111', 3),
(18, 7, 'DR. SEJAL PATEL', 'Sardarnagar gurukul, Bhavnagar', '+91 8200065192', 'sejalpatel@gmail.com', 'sejal123', 2),
(103, 8, 'DR.NANDINI CHOPDA, DR.', 'Silver stone,Rajkot ', '+91 9696858574', 'nandinichopda@gmail.com', 'nandini123', 2),
(104, 9, 'DR.MITESH DAVRA, DR.', 'Near sumul dairy, Surat', '+91 9874563210', 'miteshdavra@gmail.com', 'mitesh123', 2),
(105, 10, 'DR.PARAS PATEL, M.D.', 'Near kakriya lake, Ahemadabad', '+91 9898565623', 'paraspatel@gmail.com', 'paras123', 2),
(106, 11, 'DR.PARITA PATEL, DR.', 'Near kakriya lake, Ahemadabad', '+91 7698589244', 'paritapatel@gmail.com', 'parita123', 2),
(107, 0, 'Nirav Nayani', '', '', 'niravnayani@gmail.com', 'nirav123', 3),
(108, 0, 'Sahdev Prajapati', '', '', 'sahdevprajapati@gmail.com', 'sahdev123', 3),
(109, 0, 'Mansi Patel', '', '', 'mansipatel@gmail.com', 'mansi123', 3),
(110, 12, 'DR.AVANI TRIVEDI, MBBS.', 'Jewels circle, Bhavnagar', '+91 9712170100', 'avanitrivedi@gmail.com', 'avani123', 2),
(111, 13, 'DR.DR. B K SHAH, BHMS.', 'Yogi chowk, Surat', '+91 9988656523', 'bkshah@gmail.com', 'bkshah123', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment_list`
--
ALTER TABLE `appointment_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctors_list`
--
ALTER TABLE `doctors_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctors_schedule`
--
ALTER TABLE `doctors_schedule`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `medical_specialty`
--
ALTER TABLE `medical_specialty`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `system_settings`
--
ALTER TABLE `system_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment_list`
--
ALTER TABLE `appointment_list`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `doctors_list`
--
ALTER TABLE `doctors_list`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `doctors_schedule`
--
ALTER TABLE `doctors_schedule`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `medical_specialty`
--
ALTER TABLE `medical_specialty`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `system_settings`
--
ALTER TABLE `system_settings`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=112;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
